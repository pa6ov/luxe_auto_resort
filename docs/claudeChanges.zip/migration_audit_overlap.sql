-- ============================================================
-- Migration: audit_log + car maintenance conflict detection
-- Run once against the luxe_auto_resort database
-- ============================================================

USE luxe_auto_resort;

-- ── Audit log table (Task 2 – audit trail) ───────────────────
CREATE TABLE IF NOT EXISTS audit_log (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    admin_id        INT          NOT NULL,
    action          VARCHAR(50)  NOT NULL COMMENT 'e.g. UPDATE_STATUS, EDIT_CAR',
    table_name      VARCHAR(64)  NOT NULL,
    record_id       INT          NOT NULL,
    previous_values JSON,
    new_values      JSON,
    created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_admin   (admin_id),
    INDEX idx_table   (table_name, record_id),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── View: overlapping bookings per car ───────────────────────
-- Admins can query this to see conflicts before marking a car
-- as unavailable / under maintenance.
CREATE OR REPLACE VIEW v_active_bookings_per_car AS
SELECT
    rc.car_id,
    c.brand,
    c.model,
    rr.id          AS request_id,
    rr.status,
    rr.start_date,
    rr.end_date,
    u.first_name,
    u.last_name,
    u.email
FROM request_cars rc
JOIN rental_requests rr ON rc.request_id = rr.id
JOIN cars c             ON rc.car_id = c.id
JOIN users u            ON rr.user_id = u.id
WHERE rr.status IN ('pending', 'approved');

-- ── Stored procedure: mark car unavailable safely ────────────
-- Returns a result set of conflicting bookings BEFORE the car
-- is set to unavailable. The application layer reads those rows
-- and warns the admin (Task 2 – conflict resolution).
DROP PROCEDURE IF EXISTS sp_mark_car_unavailable;

DELIMITER //
CREATE PROCEDURE sp_mark_car_unavailable(
    IN  p_car_id    INT,
    IN  p_admin_id  INT,
    OUT p_conflicts INT
)
BEGIN
    DECLARE v_prev_available BOOLEAN;

    -- Count overlapping active requests
    SELECT COUNT(*) INTO p_conflicts
    FROM v_active_bookings_per_car
    WHERE car_id = p_car_id;

    -- Always mark unavailable (admin's decision); caller handles warning
    SELECT available INTO v_prev_available FROM cars WHERE id = p_car_id;

    UPDATE cars SET available = FALSE WHERE id = p_car_id;

    -- Log the admin action
    INSERT INTO audit_log (admin_id, action, table_name, record_id, previous_values, new_values)
    VALUES (
        p_admin_id,
        'MARK_UNAVAILABLE',
        'cars',
        p_car_id,
        JSON_OBJECT('available', v_prev_available),
        JSON_OBJECT('available', FALSE)
    );
END //
DELIMITER ;
